using System.Collections;
using KinematicCharacterController;
using UnityEngine;

public class ShadowStep : Interactable
{
    [SerializeField] private Transform _exitPoint;
    [SerializeField] private InteractionHandler _caller;
    [SerializeField] private ParticleSystem _shadowTrailPrefab;

    private enum Direction { Left, Right };
    [SerializeField] private Direction _direction;

    private bool _canInteract = false;

    public override bool CanInteract
    {
        get => _canInteract;
        set => _canInteract = value;
    }

    public override void Interact()
    {
        _caller.Player = null;
        _canInteract = false;

        StartCoroutine(ShadowTeleportCoroutine());
    }

    private IEnumerator ShadowTeleportCoroutine()
    {
        var player = Player.Instance;
        var motor = player.GetComponent<KinematicCharacterMotor>();
        var cam = Camera.main.GetComponent<ThirdPersonCamera>();

        // Disattiva modello e collisioni
        Transform playerModel = player.transform.Find("PlayerModel");
        if (playerModel != null)
            playerModel.gameObject.SetActive(false);

        Vector3 start = player.transform.position;
        Vector3 end = _exitPoint.position;
        Quaternion endRotation = Quaternion.LookRotation(_exitPoint.forward);

        float duration = 1.0f;
        float elapsed = 0f;

        // Instanzia il sistema di particelle e muovilo
        ParticleSystem trail = Instantiate(_shadowTrailPrefab, start, Quaternion.identity);
        Transform trailTransform = trail.transform;

        // Attacca temporaneamente la camera alla scia
        cam.SetFollowTarget(trailTransform);

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            trailTransform.position = Vector3.Lerp(start, end, t);
            yield return null;
        }

        // Distruggi la scia
        Destroy(trail.gameObject);

        // Teletrasporta il player
        motor.SetPositionAndRotation(end, endRotation);

        if (playerModel != null)
            playerModel.gameObject.SetActive(true);

        // Reimposta la camera sul player
        cam.SetFollowTarget(player.transform);
    }

    void Update()
    {
        if (PlayerInput.Instance.InPossession)
        {
            if (_canInteract)
                _canInteract = false;

            _caller.Player = null;
            return;
        }

        _caller.Player = Player.Instance.gameObject;

        if (!_canInteract)
            _canInteract = true;
    }
}